import entities.*;

import javax.persistence.EntityManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.Collator;
import java.util.*;
import java.util.stream.Collectors;

public class Homework implements Runnable {
    private static final Scanner sc = new Scanner(System.in);
    private final EntityManager entityManager;
    private BufferedReader bf;

    public Homework(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.bf = new BufferedReader(new InputStreamReader(System.in));
    }

    @Override
    public void run() {
        print();
        String input = sc.nextLine();
        while (!input.equals("")) {
            try {
                switch (input) {
                    case "2":
                        ex2();
                        // в Word-овия документ пише повече от 5 символа дължина
                        // не зная защо Чочо го направи с по-малко от 5 символа...
                        break;
                    case "3":
                        ex3();
                        break;
                    case "4":
                        ex4();
                        break;
                    case "5":
                        ex5();
                        break;
                    case "6":
                        ex6();
                        break;
                    case "7":
                        ex7();
                        break;
                    case "8":
                        ex8();
                        break;
                    case "9":
                        ex9();
                        break;
                    case "10":
                        ex10();
                        break;
                    case "11":
                        ex11();
                        break;
                    case "12":
                        ex12();
                        break;
                    case "13":
                        ex13();
                        break;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Continue checking exercises");
            input = sc.nextLine();
        }

        System.out.println("Come back soon!");
    }

    private void ex13() throws IOException {
        System.out.println("Enter town name to delete: ");
        String townName = bf.readLine();

        entityManager.getTransaction().begin();
        int deletedCount = entityManager.createQuery("DELETE FROM Town t where t.name = :townName", Town.class).setParameter("townName", townName).executeUpdate();
        entityManager.getTransaction().commit();
        entityManager.flush();
        if (deletedCount > 1) {
            System.out.println(deletedCount + " addresses in " + townName + " deleted");
        } else {
            System.out.println("1 address in " + townName + " deleted");
        }
    }

    private void ex12() {
        //program that finds the max salary for each department. Filter the departments, which max salaries are not in the range between 30000 and 70000.

    }

    private void ex11() throws IOException {
        System.out.println("Enter pattern for name: ");
        String pattern = bf.readLine();

        List<Employee> list = entityManager.createQuery("select e from Employee e where e.firstName like concat(:wantedName,'%')", Employee.class).setParameter("wantedName", pattern).getResultList();
        list.forEach(e -> System.out.println(e.getFirstName() + " " + e.getLastName() + " - " + e.getJobTitle() + " - $" + e.getSalary()));
    }

    private void ex10() {
        List<Employee> employees = entityManager.createQuery("select e from Employee as e where e.department.id in (1,2,4,11)", Employee.class).getResultList();
        entityManager.getTransaction().begin();
        for (Employee employee : employees) {
            employee.setSalary(employee.getSalary().add(employee.getSalary().divide(BigDecimal.valueOf(0.12), 2, RoundingMode.HALF_EVEN)));
        }
        entityManager.getTransaction().commit();
        for (Employee employee : employees) {
            System.out.println(String.format("%s %s ($%.2f)", employee.getFirstName(), employee.getLastName(), employee.getSalary()));
        }
    }

    private void ex9() {
        List<Project> list = entityManager.createQuery("select p from Project as p order by p.startDate desc, p.name asc ", Project.class).setMaxResults(10).getResultList();

        TreeMap<String, Project> projects = new TreeMap<>();
        for (Project project : list) {
            projects.put(project.getName(), project);
        }

        for (Project project : projects.values()) {
            System.out.println("Project name: " + project.getName());
            System.out.println("\tProject Description: " + project.getDescription());
            System.out.println("\tProject Start date: " + project.getStartDate());
            System.out.println("\tProject End date: " + project.getEndDate());
        }
    }

    private void ex8() throws IOException {
        System.out.println("Enter employee id: ");
        int id = Integer.parseInt(bf.readLine());
        Employee employee = entityManager.createQuery("select e from Employee as e where e.id = :wantedId", Employee.class).setParameter("wantedId", id).getSingleResult();
        System.out.println(String.format("%s %s - %s%n%s", employee.getFirstName(), employee.getLastName(), employee.getJobTitle(), getEmployeeProjects(employee)));
    }

    private String getEmployeeProjects(Employee employee) {
        Collection<String> projects1 =
                new TreeSet<String>(Collator.getInstance());

        for (Project project : employee.getProjects()) {
            projects1.add(project.getName());
        }
        StringBuilder string = new StringBuilder();
        for (String project : projects1) {
            string.append("\t");
            string.append(project).append(System.lineSeparator());
        }
        return string.toString();
    }

    private void ex7() {
        List<Address> list = entityManager.createQuery("select a from Address as a join Employee as e on a.id = e.address.id group by a.id order by count(a.employees.size) desc", Address.class)
                .setMaxResults(10)
                .getResultList();
        list.stream().forEach(e -> {
            if (e.getEmployees().size() != 0) {
                System.out.println(e.getText() + " - " + getTownName(e) + " - " + e.getEmployees().size() + " employees");
            } else {
                System.out.println(e.getText() + " - " + getTownName(e) + " - 0 employees");
            }
        });
    }

    private String getTownName(Address e) {
        Town town = entityManager.createQuery("select t from Town as t join Address as a on t.id = a.town.id where a.id = :wantedId", Town.class)
                .setParameter("wantedId", e.getId())
                .getSingleResult();
        return town.getName();
    }

    private void ex6() throws IOException {
        System.out.println("Enter last name of employee to add address");
        String lastN = bf.readLine();
        Address address = createNewAddress("Vitoshka 15");

        entityManager.getTransaction().begin();
        Employee employee = entityManager.createQuery("select e from Employee as e where e.lastName like :lasName", Employee.class)
                .setParameter("lasName", lastN).getSingleResult();
        employee.setAddress(address);
        entityManager.getTransaction().commit();
    }

    private Address createNewAddress(String s) {
        Address adr = new Address();
        adr.setText(s);
        entityManager.getTransaction().begin();
        entityManager.persist(adr);
        entityManager.getTransaction().commit();
        return adr;
    }

    private void ex5() {
        entityManager.createQuery("select e from Employee as e where e.department.id = 6 order by e.salary asc , e.id asc", Employee.class)
                .getResultList()
                .forEach(e -> System.out.println(String.format("%s %s from Research and Development department has $%.02f salary",
                        e.getFirstName(), e.getLastName(), e.getSalary())));
    }

    private void ex4() {
        entityManager.createQuery("select e.firstName from Employee as e where e.salary > 50000").getResultList().forEach(System.out::println);
    }

    private void ex3() throws IOException {
        System.out.println("Enter employee full name: ");
        String fullName = bf.readLine();
        List<Employee> empl = entityManager.createQuery("select e from Employee as e where concat(e.firstName, ' ', e.lastName) like :name").setParameter("name", "%" + fullName + "%").getResultList();
        if (empl.size() == 0) {
            System.out.println("No");
        } else {
            System.out.println("Yes");
        }
    }

    private void ex2() {
        List<Town> towns = entityManager.createQuery("SELECT t FROM Town as t WHERE length(t.name) > 5 ", Town.class).getResultList();
        entityManager.getTransaction().begin();
        towns.forEach(entityManager::detach);
        towns.forEach(t -> t.setName(t.getName().toLowerCase()));
        towns.forEach(entityManager::merge);
        entityManager.flush();
        entityManager.getTransaction().commit();
        System.out.println(towns.size() + " town names were changed.");
    }

    private void print() {
        System.out.println("Welcome!");
        System.out.println();
        System.out.println("Before checking the homework, please make sure you've clean database!");
        System.out.println();
        System.out.println();
        System.out.println("For exercise two please press 2");
        System.out.println("For exercise three please press 3");
        System.out.println("For exercise four please press 4");
        System.out.println("For exercise five please press 5");
        System.out.println("For exercise six please press 6");
        System.out.println("For exercise seven please press 7");
        System.out.println("For exercise eight please press 8");
        System.out.println("For exercise nine please press 9");
        System.out.println("For exercise ten please press 10");
        System.out.println("For exercise eleven please press 11");
        System.out.println("For exercise twelve please press 12");
        System.out.println("For exercise thirteen please press 13");
    }
}
